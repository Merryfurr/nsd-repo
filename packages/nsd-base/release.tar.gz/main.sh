#!/bin/bash

echo "NSDown 0.2"
echo
echo "Please use nsdi to get packages or nsdu to uninstall packages."
