#!/bin/bash

echo "Dummy script, check main.sh"
