#!/bin/bash

echo "NSDown 0.1"
echo "Please use nsdi to get packages or nsdu to uninstall packages."
